import React from "react";

function admindash() {
  return <div>admindash</div>;
}

export default admindash;
